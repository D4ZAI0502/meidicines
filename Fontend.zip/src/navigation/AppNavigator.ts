import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

// Import screens
import LoginScreen from '../screens/LoginScreen';
import SignupScreen from '../screens/SignupScreen';
import HomeScreen from '../screens/HomeScreen';
import EmailVerificationScreen from '../screens/EmailVerificationScreen';
import EmailVerifiedScreen from '../screens/EmailVerifiedScreen';

// Type definitions for navigation
export type RootStackParamList = {
  Login: undefined;
  Signup: undefined;
  EmailVerification: {
    email: string;
    fullname?: string;
  };
  EmailVerified: {
    token?: string;
  };
  Home: undefined;
};

const Stack = createStackNavigator<RootStackParamList>();

const AppNavigator: React.FC = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName="Login"
        screenOptions={{
          headerStyle: {
            backgroundColor: '#28a745',
          },
          headerTintColor: '#fff',
          headerTitleStyle: {
            fontWeight: 'bold',
          },
        }}
      >
        <Stack.Screen 
          name="Login" 
          component={LoginScreen} 
          options={{
            title: 'เข้าสู่ระบบ',
            headerShown: false,
          }}
        />
        <Stack.Screen 
          name="Signup" 
          component={SignupScreen} 
          options={{
            title: 'สมัครสมาชิก',
            headerBackTitle: 'กลับ',
          }}
        />
        <Stack.Screen 
          name="EmailVerification" 
          component={EmailVerificationScreen} 
          options={{
            title: 'ยืนยันอีเมล',
            headerShown: false,
          }}
        />
        <Stack.Screen 
          name="EmailVerified" 
          component={EmailVerifiedScreen} 
          options={{
            title: 'ยืนยันสำเร็จ',
            headerShown: false,
          }}
        />
        <Stack.Screen 
          name="Home" 
          component={HomeScreen} 
          options={{
            title: 'หน้าแรก',
            headerShown: false,
            headerLeft: () => null,
          }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default AppNavigator;