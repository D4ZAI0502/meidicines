const express = require('express');
const router = express.Router();
const { signup, login, getProfile } = require('../controllers/authController');
const authenticateToken = require('../middleware/auth');

// สมัครสมาชิก
router.post('/signup', signup);

// เข้าสู่ระบบ
router.post('/login', login);

// ดึงข้อมูลผู้ใช้ (ต้องมี token)
router.get('/profile', authenticateToken, getProfile);

module.exports = router;