const User = require('../models/User');
const jwt = require('jsonwebtoken');

// สมัครสมาชิก
const signup = async (req, res) => {
  try {
    const { fullname, email, password, birth_date, weight, height } = req.body;
    
    // ตรวจสอบว่าข้อมูลครบถ้วน
    if (!fullname || !email || !password) {
      return res.status(400).json({
        success: false,
        message: 'กรุณากรอกข้อมูลให้ครบถ้วน'
      });
    }
    
    // ตรวจสอบว่า email มีอยู่แล้วหรือไม่
    const existingUser = await User.findByEmail(email);
    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: 'อีเมลนี้ถูกใช้งานแล้ว'
      });
    }
    
    // สร้างผู้ใช้ใหม่
    const newUser = await User.create({
      fullname,
      email,
      password,
      birth_date,
      weight,
      height
    });
    
    // สร้าง JWT token
    const token = jwt.sign(
      { id: newUser.id, email: newUser.email },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );
    
    res.status(201).json({
      success: true,
      message: 'สมัครสมาชิกสำเร็จ',
      data: {
        user: newUser,
        token
      }
    });
    
  } catch (error) {
    console.error('Signup error:', error);
    res.status(500).json({
      success: false,
      message: 'เกิดข้อผิดพลาดในการสมัครสมาชิก'
    });
  }
};

// เข้าสู่ระบบ
const login = async (req, res) => {
  try {
    const { email, password } = req.body;
    
    // ตรวจสอบว่าข้อมูลครบถ้วน
    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'กรุณากรอกอีเมลและรหัสผ่าน'
      });
    }
    
    // ค้นหาผู้ใช้
    const user = await User.findByEmail(email);
    if (!user) {
      return res.status(400).json({
        success: false,
        message: 'อีเมลหรือรหัสผ่านไม่ถูกต้อง'
      });
    }
    
    // ตรวจสอบรหัสผ่าน
    const isValidPassword = await User.validatePassword(password, user.password);
    if (!isValidPassword) {
      return res.status(400).json({
        success: false,
        message: 'อีเมลหรือรหัสผ่านไม่ถูกต้อง'
      });
    }
    
    // สร้าง JWT token
    const token = jwt.sign(
      { id: user.id, email: user.email },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );
    
    // ส่งข้อมูลผู้ใช้ (ไม่รวมรหัสผ่าน)
    const { password: userPassword, ...userData } = user;
    
    res.json({
      success: true,
      message: 'เข้าสู่ระบบสำเร็จ',
      data: {
        user: userData,
        token
      }
    });
    
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({
      success: false,
      message: 'เกิดข้อผิดพลาดในการเข้าสู่ระบบ'
    });
  }
};

// ดึงข้อมูลผู้ใช้
const getProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'ไม่พบข้อมูลผู้ใช้'
      });
    }
    
    res.json({
      success: true,
      data: { user }
    });
    
  } catch (error) {
    console.error('Get profile error:', error);
    res.status(500).json({
      success: false,
      message: 'เกิดข้อผิดพลาดในการดึงข้อมูลผู้ใช้'
    });
  }
};

module.exports = {
  signup,
  login,
  getProfile
};