const pool = require('../config/database');
const bcrypt = require('bcrypt');

class User {
  // สร้างผู้ใช้ใหม่
  static async create(userData) {
    const { fullname, email, password, birth_date, weight, height } = userData;
    
    // เข้ารหัสรหัสผ่าน
    const saltRounds = 10;
    const hashedPassword = await bcrypt.hash(password, saltRounds);
    
    const query = `
      INSERT INTO users (fullname, email, password, birth_date, weight, height)
      VALUES ($1, $2, $3, $4, $5, $6)
      RETURNING id, fullname, email, birth_date, weight, height, created_at
    `;
    
    const values = [fullname, email, hashedPassword, birth_date, weight, height];
    
    try {
      const result = await pool.query(query, values);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  }
  
  // ค้นหาผู้ใช้ด้วย email
  static async findByEmail(email) {
    const query = 'SELECT * FROM users WHERE email = $1';
    
    try {
      const result = await pool.query(query, [email]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  }
  
  // ตรวจสอบรหัสผ่าน
  static async validatePassword(plainPassword, hashedPassword) {
    return await bcrypt.compare(plainPassword, hashedPassword);
  }
  
  // ค้นหาผู้ใช้ด้วย ID
  static async findById(id) {
    const query = 'SELECT id, fullname, email, birth_date, weight, height, created_at FROM users WHERE id = $1';
    
    try {
      const result = await pool.query(query, [id]);
      return result.rows[0];
    } catch (error) {
      throw error;
    }
  }
}

module.exports = User;